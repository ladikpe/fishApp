<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContractFinalization extends Model
{
    //
}
