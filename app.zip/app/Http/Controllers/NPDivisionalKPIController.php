<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NPDivisionalKPIController extends Controller
{
    //
}
