<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayrollProgress extends Model
{
    protected  $fillable=  ['thread_id','progress'];
    //
}
