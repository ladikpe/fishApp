<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExitFormAnswerDetail extends Model
{
    protected $fillable=['exit_form_answer_id','exit_form_question_option_id'];
}
