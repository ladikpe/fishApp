<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeOnboardingChecklist extends Model
{
    //
}
