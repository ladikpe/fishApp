<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OffPayrollType extends Model
{
    protected $fillable=['name'];

    
}
