<?php
/**
 * Created by PhpStorm.
 * User: NnamdiAlexanderAkamu
 * Date: 9/22/2020
 * Time: 10:04 AM
 */

namespace App\Classes\Interfaces;


interface LoanTypeInterface
{

	function getName();
//	function


}