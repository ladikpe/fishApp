<table class="table table striped">
    <thead>
    <tr>
        <th>Client</th>
        <th>Project Name</th>
        <th>Project Date</th>
        <th>Project Amount</th>
        <th>Payment Status</th>
        <th>Project Status</th>
    </tr>
    </thead>
    <tbody>
    @for($i=0; $i<20; $i++)
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>pending</td>
            <td>pending</td>
        </tr>
    @endfor
    </tbody>
</table>