<div class="modal fade in modal-3d-flip-horizontal modal-info" id="compLeavePlanDayListModal" aria-hidden="true" aria-labelledby="compLeavePlanDayListModal" role="dialog" tabindex="-1">
      <div class="modal-dialog modal-lg">

          <div class="modal-content">
          <div class="modal-header" >
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title" id="training_title">Leave Plan Day List</h4>
          </div>
          
            <div class="modal-body" id="leave_plan_cont">

                
            </div>
            <div class="modal-footer">
              <div class="col-xs-12">

                  <div class="form-group">

         
                    <button type="button" class="btn btn-cancel" data-dismiss="modal">Cancel</button>
                  </div>
                  <!-- End Example Textarea -->
                </div>
             </div>
            
         </div>

      </div>
    </div>
