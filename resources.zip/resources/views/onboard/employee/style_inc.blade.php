<style>

    .page-title{
        text-transform: uppercase;
        font-size: 16px;
        position: relative;
        left: 15px;
        top: 19px;
    }


</style>