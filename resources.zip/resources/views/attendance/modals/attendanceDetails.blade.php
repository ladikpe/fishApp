<div class="modal fade in modal-3d-flip-horizontal modal-info" id="attendanceDetailsModal" aria-hidden="true" aria-labelledby="attendanceDetailsModal" role="dialog" tabindex="-1">
	    <div class="modal-dialog ">
	      <table class="table">
          
        </table>
	    </div>
	  </div>